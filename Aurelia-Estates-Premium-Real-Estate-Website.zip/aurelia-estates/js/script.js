
const PROPERTIES = [
{id:1,title:"The Glass House",location:"Beverly Hills, California",type:"Villa",price:4850000,beds:4,baths:5,sqft:4800,images:["https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=1200&q=85"],desc:"A sculptural glass residence framed by mature landscaping, private terraces and expansive city views.",features:["Floor-to-ceiling glazing","Infinity pool","Private cinema","Chef's kitchen","Smart home system","Gated grounds"]},
{id:2,title:"Ocean Crest Villa",location:"Miami, Florida",type:"Villa",price:3250000,beds:5,baths:6,sqft:5400,images:["https://images.unsplash.com/photo-1605146769289-440113cc3d00?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600607688960-e095ff83135c?auto=format&fit=crop&w=1200&q=85"],desc:"A waterfront contemporary villa designed around light, water and effortless indoor-outdoor living.",features:["Waterfront dock","Ocean-view terrace","Pool","Guest suite","Open-plan kitchen","Security system"]},
{id:3,title:"The Manhattan Residence",location:"Manhattan, New York",type:"Penthouse",price:2950000,beds:3,baths:3,sqft:2400,images:["https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85"],desc:"A refined city residence with architectural interiors and sweeping skyline perspectives.",features:["Private elevator","Skyline views","Custom millwork","Concierge","Fitness room","Rooftop access"]},
{id:4,title:"Palm Estate",location:"Dubai, UAE",type:"Estate",price:5700000,beds:6,baths:7,sqft:7200,images:["https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=85"],desc:"A dramatic private estate balancing resort-style amenities with crisp contemporary architecture.",features:["Private garden","Infinity pool","Spa","Six-car garage","Staff quarters","Entertainment suite"]},
{id:5,title:"The Modern Courtyard",location:"Austin, Texas",type:"Residence",price:1850000,beds:4,baths:4,sqft:3900,images:["https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=85"],desc:"A warm modern residence organized around a tranquil internal courtyard and generous entertaining spaces.",features:["Central courtyard","Outdoor kitchen","Studio","Pool","Library","Solar-ready roof"]},
{id:6,title:"Alpine Residence",location:"Aspen, Colorado",type:"Chalet",price:6200000,beds:5,baths:6,sqft:5700,images:["https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=1200&q=85"],desc:"A serene mountain retreat where natural stone, timber and panoramic alpine views meet modern comfort.",features:["Mountain views","Stone fireplace","Ski room","Hot tub","Wine cellar","Heated garage"]},
{id:7,title:"Canyon House",location:"Los Angeles, California",type:"Residence",price:3950000,beds:4,baths:5,sqft:4200,images:["https://images.unsplash.com/photo-1600585152915-d208bec867a1?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600566753051-5b8b0d3b9f1f?auto=format&fit=crop&w=1200&q=85"],desc:"A private canyon home with layered terraces, sculptural volumes and sunset-facing outdoor rooms.",features:["Canyon views","Infinity pool","Fire lounge","Glass walls","Office","Guest pavilion"]},
{id:8,title:"Lakeside Pavilion",location:"Lake Tahoe, Nevada",type:"Chalet",price:4750000,beds:5,baths:5,sqft:5100,images:["https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85"],desc:"An architectural lakeside escape with direct access to nature and a calm, material-led interior.",features:["Lake access","Boat house","Sauna","Fireplace","Panoramic deck","Guest suite"]},
{id:9,title:"The Garden Residence",location:"London, United Kingdom",type:"Townhouse",price:4200000,beds:4,baths:4,sqft:3300,images:["https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1600&q=85","https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=85"],desc:"A beautifully restored urban residence marrying period character with contemporary garden living.",features:["Private garden","Original details","Library","Wine room","Home office","Security"]},
];

const fallback = "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=75";

function money(n){return "$"+n.toLocaleString("en-US")}
function imgFallback(img){img.onerror=()=>{img.onerror=null;img.src=fallback}}
function card(p){
 return `<article class="property-card reveal" data-id="${p.id}">
   <a class="property-image" href="property-details.html?id=${p.id}" aria-label="View ${p.title}">
    <img loading="lazy" src="${p.images[0]}" alt="${p.title}, luxury ${p.type.toLowerCase()} in ${p.location}" onerror="imgFallback(this)">
    <span class="property-tag">${p.type}</span>
   </a>
   <div class="property-body">
    <span class="eyebrow">${p.location}</span><h3>${p.title}</h3><div class="price">${money(p.price)}</div>
    <div class="specs"><span>${p.beds} Beds</span><span>${p.baths} Baths</span><span>${p.sqft.toLocaleString()} sq ft</span></div>
    <div class="card-bottom"><a class="text-link" href="property-details.html?id=${p.id}">View Property</a><a class="btn-arrow" href="property-details.html?id=${p.id}" aria-label="Open property">↗</a></div>
   </div>
 </article>`
}

function setupHeader(){
 const header=document.querySelector(".site-header"), toggle=document.querySelector(".menu-toggle"), links=document.querySelector(".nav-links");
 const update=()=>{header?.classList.toggle("scrolled",scrollY>50);document.querySelector(".backtop")?.classList.toggle("show",scrollY>600)}
 window.addEventListener("scroll",update,{passive:true});update();
 toggle?.addEventListener("click",()=>{links.classList.toggle("open");toggle.setAttribute("aria-expanded",links.classList.contains("open"))});
 links?.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>links.classList.remove("open")));
}
function setupReveal(){
 const els=document.querySelectorAll(".reveal"); if(!("IntersectionObserver" in window)){els.forEach(e=>e.classList.add("visible"));return}
 const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");io.unobserve(e.target)}}),{threshold:.12});
 els.forEach(e=>io.observe(e));
}
function setupCounters(){
 document.querySelectorAll("[data-count]").forEach(el=>{
  const target=Number(el.dataset.count), suffix=el.dataset.suffix||"";
  const io=new IntersectionObserver(entries=>{if(!entries[0].isIntersecting)return;let start=0;const step=()=>{start+=Math.ceil(target/55);if(start>=target)start=target;el.textContent=start.toLocaleString()+suffix;if(start<target)requestAnimationFrame(step)};step();io.disconnect()},{threshold:.7});io.observe(el)
 })
}
function setupSearch(){
 const form=document.querySelector("#propertySearch"), grid=document.querySelector("#propertyGrid"); if(!form||!grid)return;
 const render=()=>{const fd=new FormData(form);const loc=(fd.get("location")||"").toString().toLowerCase();const type=fd.get("type");const min=Number(fd.get("min")||0),max=Number(fd.get("max")||Infinity),beds=Number(fd.get("beds")||0);
 let out=PROPERTIES.filter(p=>(!loc||p.location.toLowerCase().includes(loc)||p.title.toLowerCase().includes(loc))&&(!type||p.type===type)&&p.price>=min&&p.price<=max&&p.beds>=beds);
 grid.innerHTML=out.length?out.map(card).join(""):`<div class="empty"><h3>No properties match your criteria.</h3><p>Try broadening your search.</p></div>`;setupReveal()
 };
 form.addEventListener("submit",e=>{e.preventDefault();render()}); render();
}
function setupPropertyFilters(){
 const grid=document.querySelector("#propertyGrid"); if(!grid)return;
 const controls=["propertyType","priceFilter","bedFilter","sortFilter"].map(id=>document.getElementById(id)).filter(Boolean);
 const render=()=>{
  let data=[...PROPERTIES],type=document.getElementById("propertyType")?.value||"",price=document.getElementById("priceFilter")?.value||"",beds=Number(document.getElementById("bedFilter")?.value||0),sort=document.getElementById("sortFilter")?.value||"";
  data=data.filter(p=>!type||p.type===type).filter(p=>!beds||p.beds>=beds).filter(p=>price===""||price==="all"||(price==="under2"&&p.price<2000000)||(price==="2to4"&&p.price>=2000000&&p.price<=4000000)||(price==="over4"&&p.price>4000000));
  if(sort==="low")data.sort((a,b)=>a.price-b.price); if(sort==="high")data.sort((a,b)=>b.price-a.price);
  grid.innerHTML=data.length?data.map(card).join(""):`<div class="empty">No properties found.</div>`;setupReveal()
 }; controls.forEach(c=>c.addEventListener("change",render));render()
}
function setupTestimonials(){
 const quotes=[
 ["“Aurelia understood exactly what we were looking for and found it before it ever reached the wider market.”","— Daniel R., International Investor"],
 ["“The entire process felt discreet, thoughtful and exceptionally well managed. We never felt like a transaction.”","— Sofia M., Miami"],
 ["“Their advisory went far beyond the purchase. They helped us understand the opportunity from every angle.”","— Marcus L., Private Client"]
 ];let i=0,quote=document.querySelector("#quote"),author=document.querySelector("#quoteAuthor"),dots=document.querySelector("#dots");if(!quote)return;
 const render=()=>{quote.textContent=quotes[i][0];author.textContent=quotes[i][1];dots.innerHTML=quotes.map((_,x)=>`<button class="dot ${x===i?"active":""}" aria-label="Testimonial ${x+1}" data-i="${x}"></button>`).join("");dots.querySelectorAll("button").forEach(b=>b.onclick=()=>{i=Number(b.dataset.i);render()})};document.querySelector("#prevTest")?.addEventListener("click",()=>{i=(i+quotes.length-1)%quotes.length;render()});document.querySelector("#nextTest")?.addEventListener("click",()=>{i=(i+1)%quotes.length;render()});render();setInterval(()=>{i=(i+1)%quotes.length;render()},6500)
}
function setupGallery(){
 const main=document.querySelector("#mainGallery"), thumbs=document.querySelector("#galleryThumbs");if(!main||!thumbs)return;
 const id=Number(new URLSearchParams(location.search).get("id"))||1,p=PROPERTIES.find(x=>x.id===id)||PROPERTIES[0];
 document.querySelector("#detailTitle").textContent=p.title;document.querySelector("#detailLocation").textContent=p.location;document.querySelector("#detailPrice").textContent=money(p.price);document.querySelector("#detailDesc").textContent=p.desc;
 document.querySelector("#detailSpecs").innerHTML=`<div><b>${p.beds}</b><span>Bedrooms</span></div><div><b>${p.baths}</b><span>Bathrooms</span></div><div><b>${p.sqft.toLocaleString()}</b><span>Sq Ft</span></div><div><b>${p.type}</b><span>Property</span></div>`;
 document.querySelector("#features").innerHTML=p.features.map(x=>`<li>✓ ${x}</li>`).join("");
 const set=i=>{main.src=p.images[i%p.images.length];main.alt=`${p.title} gallery image ${i+1}`;thumbs.querySelectorAll("button").forEach((b,x)=>b.classList.toggle("active",x===i))};
 thumbs.innerHTML=p.images.map((src,i)=>`<button type="button" class="${i===0?"active":""}" data-i="${i}"><img src="${src}" alt="Thumbnail ${i+1}" onerror="imgFallback(this)"></button>`).join("");
 thumbs.querySelectorAll("button").forEach(b=>b.onclick=()=>set(Number(b.dataset.i)));set(0);
 document.querySelector("#inquiryProperty").value=p.title;
}
function toast(message){const t=document.querySelector("#toast");if(!t)return;t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),3200)}
function setupForms(){
 document.querySelectorAll("form[data-validate]").forEach(form=>form.addEventListener("submit",e=>{e.preventDefault();let valid=true;form.querySelectorAll("[required]").forEach(x=>{x.style.borderColor=x.value.trim()?"":"#9d3e3e";if(!x.value.trim())valid=false});if(!valid){toast("Please complete the required fields.");return}toast("Thank you. Your request has been received.");form.reset()}));
 const modal=document.querySelector("#inquiryModal"),openers=document.querySelectorAll("[data-open-inquiry]");openers.forEach(o=>o.onclick=()=>{modal?.classList.add("open");document.body.classList.add("modal-open")});document.querySelectorAll("[data-close-modal]").forEach(x=>x.onclick=()=>{modal?.classList.remove("open");document.body.classList.remove("modal-open")});
}
document.addEventListener("DOMContentLoaded",()=>{setupHeader();setupReveal();setupCounters();setupSearch();setupPropertyFilters();setupTestimonials();setupGallery();setupForms();document.querySelector(".year")&&(document.querySelector(".year").textContent=new Date().getFullYear());document.querySelector(".backtop")?.addEventListener("click",()=>scrollTo({top:0,behavior:"smooth"}));document.querySelectorAll("img").forEach(img=>imgFallback(img))});
