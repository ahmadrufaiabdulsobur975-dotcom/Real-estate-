# AURELIA ESTATES

Premium multi-page real-estate portfolio website built with HTML5, CSS3 and vanilla JavaScript.

## Files
- index.html
- properties.html
- property-details.html
- about.html
- services.html
- contact.html
- css/style.css
- js/script.js

## Run
Open `index.html` in a modern browser. No build step is required.

## Notes
- Property data and filtering are driven by vanilla JavaScript.
- Images use publicly accessible Unsplash image URLs and include graceful fallback handling.
- Forms are front-end demo forms: they validate and show a toast, but do not send email without a backend/form service.
